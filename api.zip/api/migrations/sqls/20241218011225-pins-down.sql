--Drop Tables
DROP TABLE IF EXISTS pins;