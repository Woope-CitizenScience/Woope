-- Drop user following table
DROP TABLE IF EXISTS user_follows CASCADE;