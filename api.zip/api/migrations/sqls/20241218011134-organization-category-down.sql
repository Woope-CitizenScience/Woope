-- Drop tables
DROP TABLE IF EXISTS organizations CASCADE;
DROP TABLE IF EXISTS category CASCADE;
DROP TABLE IF EXISTS organizations_category CASCADE;
DROP TABLE IF EXISTS user_organization_follows CASCADE;