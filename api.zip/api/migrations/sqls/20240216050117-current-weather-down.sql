-- Drop Weather Table
DROP TABLE IF EXISTS weather_observations;