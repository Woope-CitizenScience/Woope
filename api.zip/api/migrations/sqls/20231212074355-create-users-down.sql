-- Drop Profile Information Table
DROP TABLE IF EXISTS profile_information;

-- Drop User Refresher Tokens Table
DROP TABLE IF EXISTS user_refresh_tokens;

-- Drop Users Table
DROP TABLE IF EXISTS users CASCADE;
