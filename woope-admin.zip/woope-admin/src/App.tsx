import UserManager from "./screens/UserManager";

function App() {
  return (
    <>
      <UserManager />
    </>
  );
}

export default App;
